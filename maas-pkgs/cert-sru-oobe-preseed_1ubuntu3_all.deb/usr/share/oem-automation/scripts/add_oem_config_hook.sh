target="/usr/share/dell/scripts/oem_config.sh"

if [ -e $target ]; then
    cat << EOF >> $target
if [ -e "/usr/share/ubuntu/scripts/oem-config-general.sh" ]; then
    sh /usr/share/ubuntu/scripts/oem-config-general.sh \$1 > /var/log/oem-automation.log 2>&1
fi
EOF

fi


