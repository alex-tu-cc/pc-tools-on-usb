#/bin/bash

sudo mkdir -p /var/log/oem-automation
sudo /usr/share/oem-automation/scripts/hack_oem_oobe.sh > /var/log/oem-automation/hack_oem_oobe.log 2>&1
