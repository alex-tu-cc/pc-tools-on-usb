#!/bin/bash
flag="/usr/share/oem-automation/flags/oem-automation-before-hack"
log_dir="/var/log/oem-automation"
log_dbg="$log_dir/dbg-oobe.log"
late_cmd_location="/usr/share/ubuntu/scripts/oem-config-general.sh"
late_cmd_oobe_gconf="bash /usr/share/oem-automation/late_cmd_oobe/template-gconf.sh late"

# collect log
mkdir -p $log_dir
echo "Begin to hack OEM OOBE" >> $log_dbg

if [ -f $flag ]; then
    # collect log
    echo "In if loop for 1st ubiquity (oem-config-prepare)" >> $log_dbg

    # rm eula
    rm -f /usr/lib/ubiquity/plugins/oem-eula.py
    rm -f /usr/lib/ubiquity/plugins/dell-eula.py

    # collect log
    echo "Removed EULA" >> $log_dbg

    if [ -f $late_cmd_location ]; then
        sed -i "114i\ \ \ \ \ \ \ \ $late_cmd_oobe_gconf" $late_cmd_location
    else
        echo $late_cmd_oobe_gconf >> $late_cmd_location
    fi

    # collect log
    echo "Hooked gconf tweak in late command" >> $log_dbg

    chmod 777 $late_cmd_location

    # collect log
    echo "Hooked late command" >> $log_dbg

    /usr/share/oem-automation/scripts/add_oem_config_hook.sh
    echo "Hooked all hack commands" >> $log_dbg

    sed -i "/Plugin.prepare/c\        return [], [], {}" /usr/lib/ubiquity/plugins/dell-recovery.py
    echo "Hacked dell-recovery" >> $log_dbg

    rm -f $flag
    echo "Removed 1st flag" >> $log_dbg

    sleep 3

    reboot

fi
