if [ "$1" = "early" ]; then
    echo "oem-config-general.sh early"
elif [ "$1" = "late" ]; then
    sudo -u ubuntu gconftool-2 --get /desktop/gnome/interface/accessibility > /var/log/gconf-1.log
    ls /home > /var/log/gconf-ls.log
    sudo -u ubuntu gconftool-2 --set --type bool /desktop/gnome/interface/accessibility true
    sudo -u ubuntu gconftool-2 --get /desktop/gnome/interface/accessibility > /var/log/gconf-2.log
    #sudo gconftool-2 --set --type bool /desktop/gnome/interface/accessibility true
    echo "[org.gnome.settings-daemon.plugins.power]" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    #echo "sleep-display-ac=0" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    echo "sleep-inactive-ac-timeout=0" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    echo "sleep-inactive-battery-timeout=0" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    echo "[org.gnome.desktop.session]" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    echo "idle-delay=0" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    echo "[org.gnome.desktop.screensaver]" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    echo "ubuntu-lock-on-suspend=false" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    echo "lock-enabled=false" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    echo "idle-activation-enabled=false" >> /usr/share/glib-2.0/schemas/certification.gschema.override
    glib-compile-schemas /usr/share/glib-2.0/schemas
    echo "[LightDM]" >> /etc/lightdm/lightdm.conf
    echo "autologin-user=ubuntu" >> /etc/lightdm/lightdm.conf
    echo "[SeatDefaults]" >> /etc/lightdm/lightdm.conf
    echo "autologin-user=ubuntu" >> /etc/lightdm/lightdm.conf
else
    echo "Unknown arguments $1 $2 $3 $4"
fi

