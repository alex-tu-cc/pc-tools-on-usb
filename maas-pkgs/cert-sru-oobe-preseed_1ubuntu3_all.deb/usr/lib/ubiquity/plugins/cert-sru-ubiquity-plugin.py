#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# cert-sru-ubiquity-plugin
#
# Ubiquity plugin used to automate OEM installation.
#
# Author:
#  - Pierre Equoy (ePierre) <pierre.equoy@canonical.com>

import os
from ubiquity import plugin
################################
NAME = 'cert-sru-ubiquity-plugin'
#AFTER = None
BEFORE = 'language'
WEIGHT = 15
OEM = True

class Page(plugin.Plugin):
    def ok_handler(self):
        self.debug('CERT-SRU: Page.ok_handler called')
        plugin.Plugin.ok_handler(self)

    def prepare(self, unfiltered=False):
        self.debug('CERT-SRU: Page.prepare called')
        flag = "/usr/share/oem-automation/flags/oem-automation-before-hack"
        if os.path.isfile(flag):
            self.debug('CERT-SRU: Page.prepare called - if hack')
            # ubiquity hack
            sub_command = "/usr/share/oem-automation/scripts/hack_oem_oobe-wrapper.sh"
            os.popen(sub_command)

        self.debug('CERT-SRU: Page.prepare called - begin to preseed')
        # preseed
        self.preseed('time/zone', 'Asia/Taipei')
        # DEBUG
        #import time
        #lt = time.localtime()
        #localtime = str(lt.tm_year) + str(lt.tm_mon) + str(lt.tm_mday) + " " +\
        #            str(lt.tm_hour) + str(lt.tm_min) + str(lt.tm_sec)
        #self.localtime = localtime
        #self.preseed('passwd/user-fullname', 'Test Pierre ' + localtime)
        # locale
        #self.preseed('localechooser/languagelist', 'en', seen=False)
        self.preseed('debian-installer/language', 'en')
        #self.preseed('debconf/language', 'en')
        #self.preseed('debian-installer/locale', 'en_US.UTF-8')
        # time zone
        self.preseed('time/zone', 'Asia/Taipei')
        # keyboard
        self.preseed('keyboard-configuration/xkb-keymap','us')
        self.preseed('keyboard-configuration/layoutcode','us')
        self.preseed('keyboard-configuration/layout','English (US)')
        self.preseed('keyboard-configuration/variant','English (US)')
        # user-setup
        self.preseed('passwd/user-fullname', 'ubuntu')
        self.preseed('netcfg/get_hostname', 'CANONICALID')
        self.preseed('netcfg/hostname', 'CANONICALID')
        self.preseed('passwd/username', 'ubuntu')
        self.preseed('passwd/user-password', 'insecure')
        self.preseed('passwd/user-password-again', 'insecure')
        self.preseed('passwd/root-password', 'insecure')
        self.preseed_bool('passwd/auto-login', True)
        self.preseed('ubiquity/text/99_grub_menu', 'PROVISIONSELF#OS#')
        self.debug('CERT-SRU: Page.prepare called - preseeded')


        command = []
        questions = []
        environ = {}

        return command, questions, environ

    def run(self, priority, question):
        self.debug('CERT-SRU: Page.run called')
        return plugin.Plugin.run(self, priority, question)

    def cleanup(self):
        plugin.Plugin.cleanup(self)
        self.frontend.stop_debconf()

class PageGtk(plugin.Plugin):
    plugin_title = 'ubiquity/text/cert_heading_label'

    def __init__(self, controller, *args, **kwargs):
        self.controller = controller
        from gi.repository import Gtk
        builder = Gtk.Builder()
        self.controller.add_builder(builder)
        builder.add_from_file(os.path.join(
            os.environ['UBIQUITY_GLADE'], 'stepCertPreseed.ui'))
        # get the object defined by ui via ID
        self.page = builder.get_object('stepCertPreseed')
        # seems to be necessary to hookup and show slides
        self.plugin_widgets = self.page
        self.debug('CERT-SRU: PageGtk.__init__ called')

